public class CanalTransacao {
    public static final String INTERNET_BANKING = "BANCO DIGITAL";
    public static final String CAIXA_ELETRONICO = "CAIXA ELETRONICO";
    public static final String CAIXA_FISICO = "CAIXA FISICO";


public static String getInternetBanking() {
        return INTERNET_BANKING;
    }
    public static String getCaixaEletronico() {
        return CAIXA_ELETRONICO;
    }
    public static String getCaixaFisico() {
        return CAIXA_FISICO;
    }
    @Override
    public String toString() {
        return "CanalTransacao []";
    }

}
