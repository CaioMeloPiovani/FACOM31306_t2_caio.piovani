public class Clientes extends Pessoa {

    private String estadoCivil;
    private String escolaridade;

    private Agencia agencia;

    public Clientes(String cpf, String nome, String endereco, String estadoCivil, String escolaridade,
            String dataNascimento) {
        super(cpf, nome, dataNascimento, endereco);

        this.estadoCivil = estadoCivil;
        this.escolaridade = escolaridade;

    }

    public Clientes(String cpf, String nome) {
        super(cpf, nome, null, null);
    }



    public Clientes() {
        super(null, null, null, null);
    }


    public Agencia getAgencia() {
        return agencia;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public void setAgencia(Agencia agencia) {
        this.agencia = agencia;
    }

}
