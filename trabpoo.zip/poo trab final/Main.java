import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("====== MENU DE ACESSO ======");
            System.out.println("1. Acesso Administrativo");
            System.out.println("2. Acesso Funcionário");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    MenuSistema.menuAdministrativo();
                    break;
                case 2:
                    MenuSistema.menuFuncionario();
                    break;
                case 0:
                    System.out.println("Encerrando sistema...");
                    return;
                default:
                    System.out.println("Opção inválida.");
                
                sc.close();
            }
        }
    }
}
