import java.util.*;

public class MenuSistema {
    static Scanner scanner = new Scanner(System.in);
    static List<Agencia> agencias = new ArrayList<>();
    static List<Funcionario> funcionarios = new ArrayList<>();
    static List<Clientes> clientes = new ArrayList<>();

    public static void menuAdministrativo() {
        int opcao;
        do {
            System.out.println("\n=== MENU ADMINISTRATIVO ===");
            System.out.println("1. Cadastrar nova agência");
            System.out.println("2. Listar agências");
            System.out.println("3. Cadastrar funcionário");
            System.out.println("4. Listar funcionários");
            System.out.println("5. Aumentar salário de um funcionário");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarAgencia();
                    break;
                case 2:
                    listarAgencias();
                    break;
                case 3:
                    cadastrarFuncionario();
                    break;
                case 4:
                    listarFuncionarios();
                    break;
                case 5:
                    aumentarSalario();
                    break;
            }
        } while (opcao != 0);
    }

    public static void menuFuncionario() {
        int opcao;
        do {
            System.out.println("\n=== MENU FUNCIONÁRIO ===");
            System.out.println("1. Cadastrar cliente");
            System.out.println("2. Listar clientes");
            System.out.println("3. Consultar saldo de um cliente");
            System.out.println("4. Realizar depósito");
            System.out.println("5. Realizar saque");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;
                case 2:
                    listarClientes();
                    break;
                case 3:
                    consultarSaldo();
                    break;
                case 4:
                    realizarDeposito();
                    break;
                case 5:
                    realizarSaque();
                    break;
            }
        } while (opcao != 0);
    }

    // Métodos auxiliares:
    private static void cadastrarAgencia() {
        System.out.print("Número: ");
        int numero = scanner.nextInt(); scanner.nextLine();
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Cidade: ");
        String cidade = scanner.nextLine();
        System.out.print("Estado: ");
        String estado = scanner.nextLine();
        System.out.print("Bairro: ");
        String bairro = scanner.nextLine();
        Agencia agencia = new Agencia(numero, nome, cidade, estado, bairro, null);
        agencias.add(agencia);
        System.out.println("Agência cadastrada.");
    }

    private static void listarAgencias() {
        for (Agencia a : agencias) {
            System.out.println("Agência: " + a);
        }
    }

    private static void cadastrarFuncionario() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("Carteira de Trabalho: ");
        String carteira = scanner.nextLine();
        System.out.print("RG: ");
        String rg = scanner.nextLine();
        System.out.print("Nascimento: ");
        String nascimento = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Sexo: ");
        String sexo = scanner.nextLine();
        System.out.print("Estado Civil: ");
        String civil = scanner.nextLine();
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        System.out.print("Salário: ");
        double salario = scanner.nextDouble(); scanner.nextLine();
        System.out.print("Ano de Ingresso: ");
        String ano = scanner.nextLine();
        funcionarios.add(new Funcionario(cpf, nome, carteira, rg, nascimento, endereco, sexo, civil, cargo, salario, ano));
        System.out.println("Funcionário cadastrado.");
    }

    private static void listarFuncionarios() {
        for (Funcionario f : funcionarios) {
            System.out.println("Funcionário: " + f);
        }
    }

    private static void aumentarSalario() {
        System.out.print("CPF do funcionário: ");
        String cpf = scanner.nextLine();
        for (Funcionario f : funcionarios) {
            if (f.getCpf().equals(cpf)) {
                double novoSalario = f.calcularSalario(f.getSalario());
                System.out.println("Novo salário: " + novoSalario);
                return;
            }
        }
        System.out.println("Funcionário não encontrado.");
    }

    private static void cadastrarCliente() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Estado Civil: ");
        String civil = scanner.nextLine();
        System.out.print("Escolaridade: ");
        String escolaridade = scanner.nextLine();
        System.out.print("Data de nascimento: ");
        String dataNasc = scanner.nextLine();
        clientes.add(new Clientes(cpf, nome, endereco, civil, escolaridade, dataNasc));
        System.out.println("Cliente cadastrado.");
    }

    private static void listarClientes() {
        for (Clientes c : clientes) {
            System.out.println("Cliente: " + c);
        }
    }

    private static void consultarSaldo() {
        System.out.println("Funcionalidade ainda não implementada completamente.");
    }

    private static void realizarDeposito() {
        System.out.println("Funcionalidade ainda não implementada completamente.");
    }

    private static void realizarSaque() {
        System.out.println("Funcionalidade ainda não implementada completamente.");
    }
}
