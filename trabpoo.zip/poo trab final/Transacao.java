import java.io.Serializable;

public class Transacao implements Serializable{
    private String tipo;
    private double valor;
    private String data;
    private Conta conta;
    private String canal;

    public Transacao(String tipo, double valor, String data, Conta conta, String canal){
        this.tipo = tipo;
        this.valor = valor;
        this.data = data;
        this.conta = conta;
        this.canal = canal;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }
    public String getCanal() {
        return canal;
    }
    public void setCanal(String canal) {
        this.canal = canal;
    }
    public Conta getConta(){
        return conta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
    
}