public class TratamentoClientesException extends Exception{
    public TratamentoClientesException(String mensagem){
        super(mensagem);
    }
}
